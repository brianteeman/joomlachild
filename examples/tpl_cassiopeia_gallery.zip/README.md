# Cassiopeia Gallery
Cassiopeia child template containing a template override to create a photo gallery from a blog category.